package main

import "github.com/transifex/cli/cmd/tx"

func main() { tx.Main() }
